
import React from 'react';
import { CartProvider } from './features/ordering/CartProvider';
import { ContentProvider, useContent } from './features/admin/ContentProvider';
import CartModal from './features/ordering/CartModal';
import MenuSection from './features/ordering/MenuSection';
import ComboSection from './features/ordering/ComboSection';
import GallerySection from './features/ordering/GallerySection';
import AdminPanel from './features/admin/AdminPanel';
import TrackOrder from './features/ordering/TrackOrder';
import './App.css';

function AppContent() {
  const { content } = useContent();
  const { hero, about, testimonials, contact, footer, gallery } = content;

  // Hero background style: if backgroundUrl provided, overlay semi-transparent gradient on image; else use default gradient
  const heroStyle = hero.backgroundUrl
    ? {
        backgroundImage: `linear-gradient(135deg, rgba(255,107,53,0.4), rgba(247,147,30,0.4)), url(${hero.backgroundUrl})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
      }
    : undefined;

  return (
    <div className="App">
      {/* Hero Section */}
      <header className="hero" style={heroStyle}>
        <div className="hero-content">
          <h1 className="hero-title">{hero.title}</h1>
          <p className="hero-description">{hero.description}</p>
          <button className="cta-button">{hero.ctaButton}</button>
        </div>
      </header>

      {/* About Section */}
      <section className="about">
        <div className="container">
          <h2 className="section-title">Về Chúng Tôi</h2>
          <div className="about-grid">
            <div className="about-text">
              {about.paragraphs.map((paragraph, index) => (
                <p key={index}>{paragraph}</p>
              ))}
            </div>
            <div className="about-image">
              {about.imageUrl ? (
                <img src={about.imageUrl} alt="About Us" className="about-img" />
              ) : (
                <div className="placeholder-icon">🍲</div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Menu Section */}
      <MenuSection />

      {/* Combo Section */}
      <ComboSection />

      {/* Gallery Section */}
      {gallery.length > 0 && <GallerySection images={gallery} />}

      {/* Testimonials Section */}
      <section className="testimonials">
        <div className="container">
          <h2 className="section-title">Khách Hàng Nói Gì</h2>
          <div className="testimonials-grid">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="testimonial">
                <p>"{testimonial.quote}"</p>
                <cite>- {testimonial.author}</cite>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="contact">
        <div className="container">
          <h2 className="section-title">Liên Hệ Với Chúng Tôi</h2>
          <div className="contact-grid">
            <div className="contact-info">
              <h3>Địa Chỉ</h3>
              <p>{contact.address}</p>
              <p>Điện thoại: {contact.phone}</p>
              <p>Email: {contact.email}</p>
              <p>Giờ Mở Cửa: {contact.hours}</p>
            </div>
            <form className="contact-form">
              <input type="text" placeholder="Tên của bạn" required />
              <input type="email" placeholder="Email" required />
              <textarea placeholder="Tin nhắn" rows={4} required></textarea>
              <button type="submit">Gửi Tin Nhắn</button>
            </form>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="footer">
        <div className="container">
          <p dangerouslySetInnerHTML={{ __html: footer }}></p>
        </div>
      </footer>

      <CartModal />
      <TrackOrder />
      <AdminPanel />
    </div>
  );
}

function App() {
  return (
    <ContentProvider>
      <CartProvider>
        <AppContent />
      </CartProvider>
    </ContentProvider>
  );
}

export default App;
