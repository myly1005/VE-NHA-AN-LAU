
export const playNotificationSound = () => {
  // Use Web Audio API to generate a simple, professional "ding" sound (no external files needed)
  const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
  const oscillator = audioContext.createOscillator();
  const gainNode = audioContext.createGain();

  oscillator.connect(gainNode);
  gainNode.connect(audioContext.destination);

  // Parameters for a chime-like sound: C major note, fade in/out
  oscillator.frequency.setValueAtTime(523.25, audioContext.currentTime); // C5 note
  oscillator.type = 'sine';

  gainNode.gain.setValueAtTime(0, audioContext.currentTime);
  gainNode.gain.linearRampToValueAtTime(0.3, audioContext.currentTime + 0.01); // Quick fade in
  gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 1.5); // Fade out over 1.5s

  oscillator.start(audioContext.currentTime);
  oscillator.stop(audioContext.currentTime + 1.5);

  // Resume context if suspended (for user interaction requirement)
  if (audioContext.state === 'suspended') {
    audioContext.resume();
  }
};
