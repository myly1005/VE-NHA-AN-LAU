
import { Order } from '../features/admin/types';

export const exportOrdersToCSV = (orders: Order[], filename?: string) => {
  const headers = [
    'ID Đơn Hàng',
    'Thời Gian Đặt',
    'Trạng Thái',
    'Tên Khách Hàng',
    'SĐT',
    'Địa Chỉ',
    'Ghi Chú',
    'Tổng Tiền (VNĐ)',
    'Chi Tiết Món Ăn'
  ];

  const rows = orders.map(order => {
    const items = order.items.map(item => 
      `${item.name} x${item.quantity} (${item.price.toLocaleString()} VNĐ)`
    ).join(' | ');
    
    return [
      order.id.slice(-6), // Only last 6 digits for simplicity
      new Date(order.timestamp).toLocaleString('vi-VN'),
      order.status,
      order.customer.name,
      order.customer.phone,
      order.customer.address,
      order.customer.notes || 'Không có',
      order.total.toLocaleString(),
      items
    ];
  });

  // Escape quotes and join with commas
  const csvContent = [
    headers.join(','),
    ...rows.map(row => row.map(cell => 
      typeof cell === 'string' ? `"${cell.replace(/"/g, '""')}"` : cell
    ).join(','))
  ].join('\n');

  const blob = new Blob([new TextEncoder().encode('\ufeff' + csvContent)], { 
    type: 'text/csv;charset=utf-8;' 
  }); // UTF-8 BOM for Excel compatibility

  const link = document.createElement('a');
  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', filename || `don_hang_${new Date().toISOString().slice(0, 10)}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
};

export const exportSingleOrderToCSV = (order: Order) => {
  exportOrdersToCSV([order], `don_hang_${order.id.slice(-6)}_${new Date().toISOString().slice(0, 10)}.csv`);
};
