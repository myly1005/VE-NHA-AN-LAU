
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { SiteContent, Order } from './types';
import { persistence } from '../../utils/persistence';
import { defaultContent } from './data';
import { playNotificationSound } from '../../utils/sound';

interface ContentContextType {
  content: SiteContent;
  updateContent: (newContent: Partial<SiteContent>) => void;
  saveContent: () => Promise<void>;
  addOrder: (order: Order) => void;
  getOrders: () => Order[];
  toggleSound: (enabled: boolean) => void;
}

const ContentContext = createContext<ContentContextType | undefined>(undefined);

export const useContent = () => {
  const context = useContext(ContentContext);
  if (!context) {
    throw new Error('useContent must be used within a ContentProvider');
  }
  return context;
};

interface ContentProviderProps {
  children: ReactNode;
}

const CONTENT_KEY = 'siteContent';
const ORDERS_KEY = 'orders';

export const ContentProvider: React.FC<ContentProviderProps> = ({ children }) => {
  const [content, setContent] = useState<SiteContent>(defaultContent);

  useEffect(() => {
    const loadContent = async () => {
      const saved = await persistence.getItem(CONTENT_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        // Merge with defaults to ensure all fields exist
        setContent({
          ...defaultContent,
          ...parsed,
          hero: { ...defaultContent.hero, ...parsed.hero },
          about: { ...defaultContent.about, ...parsed.about, paragraphs: parsed.about?.paragraphs || defaultContent.about.paragraphs },
          contact: { ...defaultContent.contact, ...parsed.contact },
          testimonials: parsed.testimonials || defaultContent.testimonials,
          menuItems: parsed.menuItems || defaultContent.menuItems,
          combos: parsed.combos || defaultContent.combos,
          gallery: parsed.gallery || defaultContent.gallery,
          footer: parsed.footer || defaultContent.footer,
          orders: parsed.orders || defaultContent.orders,
          soundEnabled: parsed.soundEnabled ?? defaultContent.soundEnabled,
        });
      }
    };
    loadContent();
  }, []);

  const updateContent = (newContent: Partial<SiteContent>) => {
    setContent((prev) => ({
      ...prev,
      ...newContent,
      hero: { ...prev.hero, ...newContent.hero },
      about: { ...prev.about, ...newContent.about, paragraphs: newContent.about?.paragraphs || prev.about.paragraphs },
      contact: { ...prev.contact, ...newContent.contact },
      testimonials: newContent.testimonials || prev.testimonials,
      menuItems: newContent.menuItems || prev.menuItems,
      combos: newContent.combos || prev.combos,
      gallery: newContent.gallery || prev.gallery,
      footer: newContent.footer || prev.footer,
      orders: newContent.orders || prev.orders,
      soundEnabled: newContent.soundEnabled ?? prev.soundEnabled,
    }));
  };

  const saveContent = async () => {
    await persistence.setItem(CONTENT_KEY, JSON.stringify(content));
    // Save orders separately for quick access
    await persistence.setItem(ORDERS_KEY, JSON.stringify(content.orders));
  };

  const addOrder = async (order: Order) => {
    const currentOrders = content.orders || [];
    const updatedOrders = [...currentOrders, order];
    updateContent({ orders: updatedOrders });
    await saveContent();

    // Play notification sound if enabled and order is new (status 'received')
    if (content.soundEnabled && order.status === 'received') {
      try {
        playNotificationSound();
        console.log('🔔 Notification sound played for new order:', order.id);
      } catch (error) {
        console.warn('Sound playback failed:', error);
        // Fallback: Visual alert could be added here, e.g., show a toast
      }
    }
  };

  const toggleSound = (enabled: boolean) => {
    updateContent({ soundEnabled: enabled });
    saveContent();
  };

  const getOrders = () => content.orders || [];

  return (
    <ContentContext.Provider value={{ content, updateContent, saveContent, addOrder, getOrders, toggleSound }}>
      {children}
    </ContentContext.Provider>
  );
};
