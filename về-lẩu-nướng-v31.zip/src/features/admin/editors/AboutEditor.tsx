
import React, { useState } from 'react';
import { useContent } from '../ContentProvider';
import { AboutContent } from '../types';
import './common.css';

const AboutEditor: React.FC = () => {
  const { content, updateContent } = useContent();
  const { about } = content;
  const [paragraphs, setParagraphs] = useState<string[]>(about.paragraphs);
  const [imageUrl, setImageUrl] = useState<string>(about.imageUrl || '');

  const handleParagraphChange = (index: number, value: string) => {
    const newParagraphs = [...paragraphs];
    newParagraphs[index] = value;
    setParagraphs(newParagraphs);
    updateContent({ about: { paragraphs: newParagraphs } });
  };

  const addParagraph = () => {
    const newParagraphs = [...paragraphs, ''];
    setParagraphs(newParagraphs);
    updateContent({ about: { paragraphs: newParagraphs } });
  };

  const removeParagraph = (index: number) => {
    const newParagraphs = paragraphs.filter((_, i) => i !== index);
    setParagraphs(newParagraphs);
    updateContent({ about: { paragraphs: newParagraphs } });
  };

  const handleImageUrlChange = (value: string) => {
    setImageUrl(value);
    updateContent({ about: { ...about, imageUrl: value } });
  };

  const handleImageFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const base64 = e.target?.result as string;
        setImageUrl(base64);
        updateContent({ about: { ...about, imageUrl: base64 } });
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="editor-section">
      <h3>Chỉnh Sửa About Section</h3>
      <div className="form-group">
        <label>URL Hình Ảnh (About Image):</label>
        <input
          type="url"
          value={imageUrl}
          onChange={(e) => handleImageUrlChange(e.target.value)}
          placeholder="Nhập URL hình ảnh (hoặc base64 string)"
        />
        <label>Tải Lên Hình Ảnh About:</label>
        <input
          type="file"
          accept="image/*"
          onChange={handleImageFileChange}
        />
        {imageUrl && (
          <div className="image-preview">
            <img src={imageUrl} alt="Preview" style={{ maxWidth: '200px', maxHeight: '150px', marginTop: '10px' }} />
          </div>
        )}
      </div>
      {paragraphs.map((paragraph, index) => (
        <div key={index} className="paragraph-group">
          <textarea
            value={paragraph}
            onChange={(e) => handleParagraphChange(index, e.target.value)}
            placeholder={`Đoạn ${index + 1}`}
            rows={3}
          />
          <button type="button" onClick={() => removeParagraph(index)} className="remove-btn">
            Xóa
          </button>
        </div>
      ))}
      <button type="button" onClick={addParagraph} className="add-btn">
        Thêm Đoạn
      </button>
    </div>
  );
};

export default AboutEditor;
