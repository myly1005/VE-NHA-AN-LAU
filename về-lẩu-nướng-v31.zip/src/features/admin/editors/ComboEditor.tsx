
import React, { useState } from 'react';
import { useContent } from '../ContentProvider';
import { ComboContent } from '../types';
import './common.css';

const ComboEditor: React.FC = () => {
  const { content, updateContent } = useContent();
  const { combos } = content;
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<ComboContent>({
    id: '',
    name: '',
    description: '',
    price: 0,
    includes: [],
    gift: '',
    icon: '',
    imageUrl: '',
  });

  const handleInputChange = (field: keyof ComboContent, value: string | number) => {
    setEditForm((prev) => ({ ...prev, [field]: value }));
  };

  const handleIncludeChange = (index: number, value: string) => {
    setEditForm((prev) => {
      const newIncludes = [...(prev.includes || [])];
      newIncludes[index] = value;
      return { ...prev, includes: newIncludes };
    });
  };

  const addInclude = () => {
    setEditForm((prev) => ({
      ...prev,
      includes: [...(prev.includes || []), ''],
    }));
  };

  const removeInclude = (index: number) => {
    setEditForm((prev) => ({
      ...prev,
      includes: (prev.includes || []).filter((_, i) => i !== index),
    }));
  };

  const startEdit = (item: ComboContent) => {
    setEditingId(item.id);
    setEditForm(item);
  };

  const saveEdit = () => {
    if (editingId) {
      const newCombos = combos.map((item) => (item.id === editingId ? editForm : item));
      setEditForm({ id: '', name: '', description: '', price: 0, includes: [], gift: '', icon: '', imageUrl: '' });
      updateContent({ combos: newCombos });
      setEditingId(null);
    }
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditForm({ id: '', name: '', description: '', price: 0, includes: [], gift: '', icon: '', imageUrl: '' });
  };

  const addItem = () => {
    const newId = `c${combos.length + 1}`;
    const newItem: ComboContent = {
      id: newId,
      name: '',
      description: '',
      price: 0,
      includes: [],
      gift: '',
      icon: '',
      imageUrl: '',
    };
    const newCombos = [...combos, newItem];
    updateContent({ combos: newCombos });
    startEdit(newItem);
  };

  const deleteItem = (id: string) => {
    const newCombos = combos.filter((item) => item.id !== id);
    updateContent({ combos: newCombos });
  };

  const handleImageFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const base64 = e.target?.result as string;
        setEditForm((prev) => ({ ...prev, imageUrl: base64 }));
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="editor-section">
      <h3>Chỉnh Sửa Combos</h3>
      <button type="button" onClick={addItem} className="add-btn">
        Thêm Combo Mới
      </button>
      <ul className="menu-list">
        {combos.map((item) => (
          <li key={item.id} className="menu-item-editor">
            {editingId === item.id ? (
              <div className="edit-form">
                <input
                  type="text"
                  placeholder="Tên combo"
                  value={editForm.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                />
                <textarea
                  placeholder="Mô tả (tùy chọn)"
                  value={editForm.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  rows={2}
                />
                <input
                  type="number"
                  placeholder="Giá (VNĐ)"
                  value={editForm.price}
                  onChange={(e) => handleInputChange('price', parseInt(e.target.value) || 0)}
                />
                <div className="includes-section">
                  <h4>Bao gồm:</h4>
                  {(editForm.includes || []).map((include, index) => (
                    <div key={index} className="paragraph-group">
                      <input
                        type="text"
                        value={include}
                        onChange={(e) => handleIncludeChange(index, e.target.value)}
                        placeholder={`Món ${index + 1}`}
                      />
                      <button type="button" onClick={() => removeInclude(index)} className="remove-btn">
                        Xóa
                      </button>
                    </div>
                  ))}
                  <button type="button" onClick={addInclude} className="add-btn">
                    Thêm Món
                  </button>
                </div>
                <div className="form-group">
                  <label>Tặng kèm (tùy chọn):</label>
                  <textarea
                    value={editForm.gift || ''}
                    onChange={(e) => handleInputChange('gift', e.target.value)}
                    placeholder="Tặng kèm..."
                    rows={2}
                  />
                </div>
                <input
                  type="text"
                  placeholder="Icon (emoji)"
                  value={editForm.icon}
                  onChange={(e) => handleInputChange('icon', e.target.value)}
                />
                <input
                  type="url"
                  placeholder="URL Hình Ảnh (tùy chọn)"
                  value={editForm.imageUrl || ''}
                  onChange={(e) => handleInputChange('imageUrl', e.target.value)}
                />
                <label>Tải Lên Hình Ảnh Combo:</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageFileChange}
                />
                {editForm.imageUrl && (
                  <div className="image-preview">
                    <img src={editForm.imageUrl} alt="Preview" style={{ maxWidth: '100px', maxHeight: '100px' }} />
                  </div>
                )}
                <div className="edit-buttons">
                  <button onClick={saveEdit}>Lưu</button>
                  <button onClick={cancelEdit} className="cancel-btn">Hủy</button>
                </div>
              </div>
            ) : (
              <div className="item-preview">
                <div className="preview-image">
                  {item.imageUrl ? (
                    <img src={item.imageUrl} alt={item.name} style={{ maxWidth: '80px', maxHeight: '80px' }} />
                  ) : (
                    <span>{item.icon}</span>
                  )}
                </div>
                <div>
                  <strong>{item.name}</strong>
                  {item.description && <p>{item.description}</p>}
                  <div className="includes-preview">
                    <strong>Bao gồm:</strong>
                    <ul>
                      {item.includes.map((inc, idx) => <li key={idx}>{inc}</li>)}
                    </ul>
                  </div>
                  {item.gift && (
                    <p className="gift-preview"><strong>Tặng kèm:</strong> {item.gift}</p>
                  )}
                  <span className="price">{item.price.toLocaleString()} VNĐ</span>
                </div>
                <div className="item-actions">
                  <button onClick={() => startEdit(item)}>Sửa</button>
                  <button onClick={() => deleteItem(item.id)} className="remove-btn">Xóa</button>
                </div>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ComboEditor;
