
import React, { useState } from 'react';
import { useContent } from '../ContentProvider';
import './common.css';

const GalleryEditor: React.FC = () => {
  const { content, updateContent } = useContent();
  const { gallery } = content;
  const [images, setImages] = useState<string[]>(gallery);
  const [newImage, setNewImage] = useState<string>('');

  const handleImageFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const base64 = e.target?.result as string;
        setNewImage(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  const addImage = () => {
    if (newImage) {
      const newImages = [...images, newImage];
      setImages(newImages);
      updateContent({ gallery: newImages });
      setNewImage('');
    }
  };

  const removeImage = (index: number) => {
    const newImages = images.filter((_, i) => i !== index);
    setImages(newImages);
    updateContent({ gallery: newImages });
  };

  return (
    <div className="editor-section">
      <h3>Chỉnh Sửa Gallery (Thêm Hình Ảnh)</h3>
      <div className="form-group">
        <label>Tải Lên Hình Ảnh Mới:</label>
        <input
          type="file"
          accept="image/*"
          onChange={handleImageFileChange}
        />
        {newImage && (
          <div className="image-preview">
            <img src={newImage} alt="Preview" style={{ maxWidth: '200px', maxHeight: '150px', marginTop: '10px' }} />
            <button type="button" onClick={addImage} className="add-btn">Thêm Vào Gallery</button>
          </div>
        )}
      </div>
      <div className="gallery-preview">
        <h4>Hình Ảnh Hiện Tại:</h4>
        {images.length === 0 ? (
          <p>Chưa có hình ảnh nào. Hãy tải lên!</p>
        ) : (
          <div className="gallery-grid">
            {images.map((image, index) => (
              <div key={index} className="gallery-item">
                <img src={image} alt={`Gallery ${index + 1}`} style={{ maxWidth: '150px', maxHeight: '150px', objectFit: 'cover', borderRadius: '8px' }} />
                <button type="button" onClick={() => removeImage(index)} className="remove-btn">Xóa</button>
              </div>
            ))}
          </div>
        )}
      </div>
      <p style={{ fontSize: '0.9rem', color: '#666', marginTop: '10px' }}>
        Lưu ý: Hình ảnh sẽ được lưu dưới dạng base64 và hiển thị trong phần Gallery trên trang web. Sử dụng Admin Panel để quản lý.
      </p>
    </div>
  );
};

export default GalleryEditor;
