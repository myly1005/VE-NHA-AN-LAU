
import React from 'react';
import { useContent } from '../ContentProvider';
import { ContactContent } from '../types';
import './common.css';

const ContactEditor: React.FC = () => {
  const { content, updateContent } = useContent();
  const { contact } = content;

  const handleChange = (field: keyof ContactContent, value: string) => {
    updateContent({ contact: { ...contact, [field]: value } });
  };

  return (
    <div className="editor-section">
      <h3>Chỉnh Sửa Contact Section</h3>
      <div className="form-group">
        <label>Địa Chỉ:</label>
        <input
          type="text"
          value={contact.address}
          onChange={(e) => handleChange('address', e.target.value)}
          placeholder="Địa chỉ"
        />
      </div>
      <div className="form-group">
        <label>Điện Thoại:</label>
        <input
          type="text"
          value={contact.phone}
          onChange={(e) => handleChange('phone', e.target.value)}
          placeholder="Số điện thoại"
        />
      </div>
      <div className="form-group">
        <label>Email:</label>
        <input
          type="email"
          value={contact.email}
          onChange={(e) => handleChange('email', e.target.value)}
          placeholder="Email"
        />
      </div>
      <div className="form-group">
        <label>Giờ Mở Cửa:</label>
        <input
          type="text"
          value={contact.hours}
          onChange={(e) => handleChange('hours', e.target.value)}
          placeholder="Giờ mở cửa"
        />
      </div>
    </div>
  );
};

export default ContactEditor;
