
import React, { useState, useEffect } from 'react';
import { useContent } from '../ContentProvider';
import { Order } from '../types';
import { persistence } from '../../../utils/persistence';
import { exportOrdersToCSV } from '../../../utils/exportUtils';
import './common.css';
import './OrdersEditor.css';

const statusOptions = [
  { value: 'received', label: 'Nhận Đơn' },
  { value: 'preparing', label: 'Đang Chuẩn Bị' },
  { value: 'ready', label: 'Sẵn Sàng Giao' },
  { value: 'delivered', label: 'Đã Giao' },
  { value: 'cancelled', label: 'Đã Hủy' },
];

const OrdersEditor: React.FC = () => {
  const { content, updateContent, saveContent, toggleSound } = useContent();
  const [orders, setOrders] = useState<Order[]>(content.orders || []);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState<{ [key: string]: boolean }>({});
  const [soundEnabled, setSoundEnabled] = useState<boolean>(content.soundEnabled);

  useEffect(() => {
    const loadOrders = async () => {
      try {
        const savedOrdersStr = await persistence.getItem('orders');
        const savedOrders: Order[] = savedOrdersStr ? JSON.parse(savedOrdersStr) : [];
        setOrders(savedOrders);
        updateContent({ orders: savedOrders });
      } catch (error) {
        console.error('Lỗi tải đơn hàng:', error);
      } finally {
        setLoading(false);
      }
    };
    loadOrders();
  }, [updateContent]);

  useEffect(() => {
    setSoundEnabled(content.soundEnabled);
  }, [content.soundEnabled]);

  const formatDate = (timestamp: number) => {
    return new Intl.DateTimeFormat('vi-VN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    }).format(timestamp);
  };

  const getStatusLabel = (status: string) => {
    const option = statusOptions.find(s => s.value === status);
    return option ? option.label : status;
  };

  const getStatusClass = (status: string) => {
    switch (status) {
      case 'received': return 'status-received';
      case 'preparing': return 'status-preparing';
      case 'ready': return 'status-ready';
      case 'delivered': return 'status-delivered';
      case 'cancelled': return 'status-cancelled';
      default: return 'status-unknown';
    }
  };

  const updateOrderStatus = async (orderId: string, newStatus: string) => {
    setUpdating(prev => ({ ...prev, [orderId]: true }));
    try {
      const updatedOrders = orders.map(order =>
        order.id === orderId ? { ...order, status: newStatus } : order
      );
      setOrders(updatedOrders);
      updateContent({ orders: updatedOrders });
      await saveContent();
      alert(`Đã cập nhật trạng thái đơn hàng ${orderId.slice(-6)} thành "${getStatusLabel(newStatus)}"`);
    } catch (error) {
      console.error('Lỗi cập nhật trạng thái:', error);
      alert('Lỗi khi cập nhật trạng thái. Vui lòng thử lại.');
    } finally {
      setUpdating(prev => ({ ...prev, [orderId]: false }));
    }
  };

  const handleSoundToggle = (e: React.ChangeEvent<HTMLInputElement>) => {
    const enabled = e.target.checked;
    setSoundEnabled(enabled);
    toggleSound(enabled);
    if (enabled) {
      // Optional: Play a test sound to confirm
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      if (audioContext.state === 'suspended') {
        audioContext.resume();
      }
    }
  };

  const clearAllOrders = async () => {
    if (window.confirm('Bạn có chắc muốn xóa tất cả đơn hàng?')) {
      await persistence.removeItem('orders');
      setOrders([]);
      updateContent({ orders: [] });
      await saveContent();
    }
  };

  const exportAllOrders = () => {
    if (orders.length === 0) {
      alert('Không có đơn hàng để xuất.');
      return;
    }
    exportOrdersToCSV(orders, `tat_ca_don_hang_${new Date().toISOString().slice(0, 10)}.csv`);
    alert('Đã tải xuống file CSV. Mở bằng Excel để xem dữ liệu.');
  };

  if (loading) {
    return <div className="editor-section">Đang tải đơn hàng...</div>;
  }

  return (
    <div className="editor-section">
      <h3>Quản Lý Đơn Hàng (Thông Báo Đặt Hàng)</h3>
      <div className="sound-settings">
        <label>
          <input
            type="checkbox"
            checked={soundEnabled}
            onChange={handleSoundToggle}
          />
          Bật âm thanh thông báo cho đơn hàng mới (tiếng "ding" vui tai)
        </label>
        <p className="sound-note">
          Âm thanh sẽ phát khi có đơn hàng mới (trạng thái 'received'). 
          Sử dụng Web Audio API – không cần file ngoài, an toàn và nhanh.
        </p>
      </div>
      <p className="orders-info">
        Tổng số đơn hàng: <strong>{orders.length}</strong> | 
        Đơn hàng mới nhất: {orders.length > 0 ? formatDate(orders[0].timestamp) : 'Chưa có'}
      </p>
      <div className="export-section">
        <button className="export-btn" onClick={exportAllOrders}>
          📊 Xuất Tất Cả Đơn Hàng Ra Excel (CSV)
        </button>
      </div>
      {orders.length > 0 ? (
        <>
          <div className="orders-list">
            {orders
              .sort((a, b) => b.timestamp - a.timestamp) // Newest first
              .map((order) => (
                <div key={order.id} className="order-item">
                  <div className="order-header">
                    <h4>Đơn hàng #{order.id.slice(-6)} - {formatDate(order.timestamp)}</h4>
                    <span className="order-total">Tổng: {order.total.toLocaleString()} VNĐ</span>
                  </div>
                  <div className="order-status">
                    <label>Trạng Thái:</label>
                    <select
                      value={order.status}
                      onChange={(e) => updateOrderStatus(order.id, e.target.value)}
                      disabled={updating[order.id]}
                    >
                      {statusOptions.map(option => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </select>
                    <span className={`status-badge ${getStatusClass(order.status)}`}>
                      {getStatusLabel(order.status)}
                    </span>
                  </div>
                  <div className="order-customer">
                    <h5>Thông tin khách hàng:</h5>
                    <p><strong>Tên:</strong> {order.customer.name}</p>
                    <p><strong>SĐT:</strong> {order.customer.phone}</p>
                    <p><strong>Địa chỉ:</strong> {order.customer.address}</p>
                    {order.customer.notes && <p><strong>Ghi chú:</strong> {order.customer.notes}</p>}
                  </div>
                  <div className="order-items">
                    <h5>Chi tiết đơn hàng:</h5>
                    <ul>
                      {order.items.map((item, index) => (
                        <li key={index} className="order-item-detail">
                          <span className="item-icon">{item.icon}</span>
                          <div className="item-details">
                            <strong>{item.name}</strong> - {item.quantity}x - {(item.price * item.quantity).toLocaleString()} VNĐ
                            {item.description && <p>{item.description}</p>}
                          </div>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              ))}
          </div>
          <button className="clear-btn" onClick={clearAllOrders}>
            Xóa Tất Cả Đơn Hàng
          </button>
        </>
      ) : (
        <p className="no-orders">Chưa có đơn hàng nào. Khi khách đặt hàng, thông báo sẽ xuất hiện ở đây (với âm thanh nếu bật).</p>
      )}
      <p className="orders-note">
        Lưu ý: Đơn hàng được tự động lưu khi khách hoàn tất đặt hàng. Cập nhật trạng thái ở đây để khách có thể theo dõi qua số điện thoại.
        Âm thanh chỉ phát cho đơn hàng mới ('received') và khi Admin Panel đang mở. File CSV có thể mở trực tiếp bằng Excel (hỗ trợ tiếng Việt).
      </p>
    </div>
  );
};

export default OrdersEditor;
