
import React, { useState } from 'react';
import { useContent } from '../ContentProvider';
import { Testimonial } from '../types';
import './common.css';

const TestimonialsEditor: React.FC = () => {
  const { content, updateContent } = useContent();
  const { testimonials } = content;
  const [items, setItems] = useState<Testimonial[]>(testimonials);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editForm, setEditForm] = useState<Testimonial>({ quote: '', author: '' });

  const handleInputChange = (field: keyof Testimonial, value: string) => {
    setEditForm((prev) => ({ ...prev, [field]: value }));
  };

  const startEdit = (index: number, item: Testimonial) => {
    setEditingId(index);
    setEditForm(item);
  };

  const saveEdit = () => {
    if (editingId !== null) {
      const newItems = [...items];
      newItems[editingId] = editForm;
      setItems(newItems);
      updateContent({ testimonials: newItems });
      setEditingId(null);
    }
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditForm({ quote: '', author: '' });
  };

  const addTestimonial = () => {
    const newItem: Testimonial = { quote: '', author: '' };
    setItems([...items, newItem]);
    updateContent({ testimonials: [...items, newItem] });
    startEdit(items.length, newItem);
  };

  const deleteTestimonial = (index: number) => {
    const newItems = items.filter((_, i) => i !== index);
    setItems(newItems);
    updateContent({ testimonials: newItems });
  };

  return (
    <div className="editor-section">
      <h3>Chỉnh Sửa Testimonials</h3>
      <button type="button" onClick={addTestimonial} className="add-btn">
        Thêm Testimonial
      </button>
      {items.map((item, index) => (
        <div key={index} className="testimonial-editor">
          {editingId === index ? (
            <div className="edit-form">
              <textarea
                placeholder="Trích dẫn"
                value={editForm.quote}
                onChange={(e) => handleInputChange('quote', e.target.value)}
                rows={3}
              />
              <input
                type="text"
                placeholder="Tác giả"
                value={editForm.author}
                onChange={(e) => handleInputChange('author', e.target.value)}
              />
              <div className="edit-buttons">
                <button onClick={saveEdit}>Lưu</button>
                <button onClick={cancelEdit} className="cancel-btn">Hủy</button>
              </div>
            </div>
          ) : (
            <div className="item-preview">
              <p>{item.quote}</p>
              <cite>{item.author}</cite>
              <div className="item-actions">
                <button onClick={() => startEdit(index, item)}>Sửa</button>
                <button onClick={() => deleteTestimonial(index)} className="remove-btn">Xóa</button>
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

export default TestimonialsEditor;
