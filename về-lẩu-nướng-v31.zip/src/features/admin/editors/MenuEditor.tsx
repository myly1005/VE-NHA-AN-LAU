
import React, { useState } from 'react';
import { useContent } from '../ContentProvider';
import { MenuItemContent } from '../types';
import './common.css';

const MenuEditor: React.FC = () => {
  const { content, updateContent } = useContent();
  const { menuItems } = content;
  const [items, setItems] = useState<MenuItemContent[]>(menuItems);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<MenuItemContent>({} as MenuItemContent);

  const handleInputChange = (field: keyof MenuItemContent, value: string | number) => {
    setEditForm((prev) => ({ ...prev, [field]: value }));
  };

  const startEdit = (item: MenuItemContent) => {
    setEditingId(item.id);
    setEditForm({ ...item });
  };

  const saveEdit = () => {
    if (editingId) {
      const newItems = items.map((item) => (item.id === editingId ? editForm : item));
      setItems(newItems);
      updateContent({ menuItems: newItems });
      setEditingId(null);
    }
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditForm({} as MenuItemContent);
  };

  const addItem = () => {
    const newId = `m${items.length + 1}`;
    const newItem: MenuItemContent = {
      id: newId,
      name: '',
      description: '',
      price: 0,
      icon: '',
      imageUrl: '',
      category: '',
    };
    setItems([...items, newItem]);
    updateContent({ menuItems: [...items, newItem] });
    startEdit(newItem);
  };

  const deleteItem = (id: string) => {
    const newItems = items.filter((item) => item.id !== id);
    setItems(newItems);
    updateContent({ menuItems: newItems });
  };

  const handleImageFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const base64 = e.target?.result as string;
        setEditForm((prev) => ({ ...prev, imageUrl: base64 }));
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="editor-section">
      <h3>Chỉnh Sửa Menu</h3>
      <button type="button" onClick={addItem} className="add-btn">
        Thêm Món Mới
      </button>
      <ul className="menu-list">
        {items.map((item) => (
          <li key={item.id} className="menu-item-editor">
            {editingId === item.id ? (
              <div className="edit-form">
                <input
                  type="text"
                  placeholder="Tên món"
                  value={editForm.name || ''}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                />
                <input
                  type="text"
                  placeholder="Danh mục (Category)"
                  value={editForm.category || ''}
                  onChange={(e) => handleInputChange('category', e.target.value)}
                />
                <input
                  type="text"
                  placeholder="Mô tả"
                  value={editForm.description || ''}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                />
                <input
                  type="number"
                  placeholder="Giá"
                  value={editForm.price || ''}
                  onChange={(e) => handleInputChange('price', parseInt(e.target.value) || 0)}
                />
                <input
                  type="text"
                  placeholder="Icon (emoji)"
                  value={editForm.icon || ''}
                  onChange={(e) => handleInputChange('icon', e.target.value)}
                />
                <input
                  type="url"
                  placeholder="URL Hình Ảnh (tùy chọn)"
                  value={editForm.imageUrl || ''}
                  onChange={(e) => handleInputChange('imageUrl', e.target.value)}
                />
                <label>Tải Lên Hình Ảnh Món Ăn:</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageFileChange}
                />
                {editForm.imageUrl && (
                  <div className="image-preview">
                    <img src={editForm.imageUrl} alt="Preview" style={{ maxWidth: '100px', maxHeight: '100px' }} />
                  </div>
                )}
                <div className="edit-buttons">
                  <button onClick={saveEdit}>Lưu</button>
                  <button onClick={cancelEdit} className="cancel-btn">Hủy</button>
                </div>
              </div>
            ) : (
              <div className="item-preview">
                <div className="preview-image">
                  {item.imageUrl ? (
                    <img src={item.imageUrl} alt={item.name} style={{ maxWidth: '80px', maxHeight: '80px' }} />
                  ) : (
                    <span>{item.icon}</span>
                  )}
                </div>
                <div>
                  <strong>{item.name}</strong>
                  {item.category && <p style={{ fontSize: '0.9rem', color: '#666' }}>Danh mục: {item.category}</p>}
                  <p>{item.description}</p>
                  <span>{item.price.toLocaleString()} VNĐ</span>
                </div>
                <div className="item-actions">
                  <button onClick={() => startEdit(item)}>Sửa</button>
                  <button onClick={() => deleteItem(item.id)} className="remove-btn">Xóa</button>
                </div>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default MenuEditor;
