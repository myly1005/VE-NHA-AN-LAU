
import React, { useState } from 'react';
import { useContent } from '../ContentProvider';
import { HeroContent } from '../types';
import './common.css';

const HeroEditor: React.FC = () => {
  const { content, updateContent } = useContent();
  const { hero } = content;
  const [backgroundUrl, setBackgroundUrl] = useState<string>(hero.backgroundUrl || '');

  const handleChange = (field: keyof HeroContent, value: string) => {
    if (field === 'backgroundUrl') {
      setBackgroundUrl(value);
    }
    updateContent({ hero: { ...hero, [field]: value } });
  };

  const handleBackgroundUrlChange = (value: string) => {
    setBackgroundUrl(value);
    updateContent({ hero: { ...hero, backgroundUrl: value } });
  };

  const handleBackgroundFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const base64 = e.target?.result as string;
        setBackgroundUrl(base64);
        updateContent({ hero: { ...hero, backgroundUrl: base64 } });
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="editor-section">
      <h3>Chỉnh Sửa Hero Section</h3>
      <div className="form-group">
        <label>Tiêu Đề:</label>
        <input
          type="text"
          value={hero.title}
          onChange={(e) => handleChange('title', e.target.value)}
          placeholder="Tiêu đề Hero"
        />
      </div>
      <div className="form-group">
        <label>Mô Tả:</label>
        <textarea
          value={hero.description}
          onChange={(e) => handleChange('description', e.target.value)}
          placeholder="Mô tả Hero"
          rows={4}
        />
      </div>
      <div className="form-group">
        <label>Nút CTA:</label>
        <input
          type="text"
          value={hero.ctaButton}
          onChange={(e) => handleChange('ctaButton', e.target.value)}
          placeholder="Text nút CTA"
        />
      </div>
      <div className="form-group">
        <label>URL Hình Ảnh Background (Hero):</label>
        <input
          type="url"
          value={backgroundUrl}
          onChange={(e) => handleBackgroundUrlChange(e.target.value)}
          placeholder="Nhập URL hình ảnh background (hoặc base64 string)"
        />
        <label>Tải Lên Hình Ảnh Background:</label>
        <input
          type="file"
          accept="image/*"
          onChange={handleBackgroundFileChange}
        />
        {backgroundUrl && (
          <div className="image-preview">
            <img 
              src={backgroundUrl} 
              alt="Background Preview" 
              style={{ 
                width: '100%', 
                maxWidth: '400px', 
                height: '200px', 
                objectFit: 'cover', 
                marginTop: '10px',
                borderRadius: '5px',
                border: '1px solid #ddd'
              }} 
            />
            <p style={{ fontSize: '0.9rem', color: '#666', marginTop: '5px' }}>
              Preview: Gradient sẽ được overlay lên hình ảnh này.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default HeroEditor;
