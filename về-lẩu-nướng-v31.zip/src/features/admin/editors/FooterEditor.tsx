
import React from 'react';
import { useContent } from '../ContentProvider';
import { SiteContent } from '../types';
import './common.css';

const FooterEditor: React.FC = () => {
  const { content, updateContent } = useContent();
  const { footer } = content;

  const handleChange = (value: string) => {
    updateContent({ footer: value });
  };

  return (
    <div className="editor-section">
      <h3>Chỉnh Sửa Footer</h3>
      <div className="form-group">
        <label>Copyright Text:</label>
        <input
          type="text"
          value={footer}
          onChange={(e) => handleChange(e.target.value)}
          placeholder="Text footer"
        />
      </div>
    </div>
  );
};

export default FooterEditor;
