
import React, { useState } from 'react';
import { useContent } from './ContentProvider';
import HeroEditor from './editors/HeroEditor';
import AboutEditor from './editors/AboutEditor';
import MenuEditor from './editors/MenuEditor';
import ComboEditor from './editors/ComboEditor';
import TestimonialsEditor from './editors/TestimonialsEditor';
import ContactEditor from './editors/ContactEditor';
import FooterEditor from './editors/FooterEditor';
import GalleryEditor from './editors/GalleryEditor';
import OrdersEditor from './editors/OrdersEditor';
import './AdminPanel.css';

const AdminPanel: React.FC = () => {
  const { saveContent } = useContent();
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('hero');
  const [saving, setSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState<string | null>(null);

  const tabs = [
    { id: 'hero', label: 'Hero' },
    { id: 'about', label: 'About' },
    { id: 'menu', label: 'Menu' },
    { id: 'combos', label: 'Combos' },
    { id: 'gallery', label: 'Gallery' },
    { id: 'testimonials', label: 'Testimonials' },
    { id: 'contact', label: 'Contact' },
    { id: 'footer', label: 'Footer' },
    { id: 'orders', label: 'Đơn Hàng' },
  ];

  const renderTabContent = () => {
    switch (activeTab) {
      case 'hero':
        return <HeroEditor />;
      case 'about':
        return <AboutEditor />;
      case 'menu':
        return <MenuEditor />;
      case 'combos':
        return <ComboEditor />;
      case 'gallery':
        return <GalleryEditor />;
      case 'testimonials':
        return <TestimonialsEditor />;
      case 'contact':
        return <ContactEditor />;
      case 'footer':
        return <FooterEditor />;
      case 'orders':
        return <OrdersEditor />;
      default:
        return null;
    }
  };

  const handleSave = async () => {
    setSaving(true);
    setSaveMessage(null);
    try {
      await saveContent();
      setSaveMessage('Đã lưu thay đổi thành công!');
    } catch (error) {
      console.error('Lỗi khi lưu:', error);
      setSaveMessage('Lỗi khi lưu thay đổi. Vui lòng thử lại.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <>
      <button className="admin-toggle" onClick={() => setIsOpen(!isOpen)}>
        {isOpen ? '✕' : '⚙️'} Admin
      </button>
      {isOpen && (
        <div className="admin-overlay">
          <div className="admin-panel">
            <div className="admin-header">
              <h2>Admin Panel - Chỉnh Sửa Nội Dung</h2>
              <button className="close-admin" onClick={() => setIsOpen(false)}>✕</button>
            </div>
            <div className="admin-tabs">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  className={`tab-btn ${activeTab === tab.id ? 'active' : ''}`}
                  onClick={() => setActiveTab(tab.id)}
                >
                  {tab.label}
                </button>
              ))}
            </div>
            <div className="admin-content">
              {renderTabContent()}
            </div>
            <div className="admin-footer">
              {saveMessage && <p className={`save-message ${saveMessage.includes('thành công') ? 'success' : 'error'}`}>{saveMessage}</p>}
              <button 
                className="save-btn" 
                onClick={handleSave}
                disabled={saving}
              >
                {saving ? 'Đang Lưu...' : 'Lưu Thay Đổi'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default AdminPanel;
