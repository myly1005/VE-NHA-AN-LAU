
import { SiteContent, HeroContent, AboutContent, Testimonial, ContactContent, MenuItemContent, ComboContent, Order } from './types';

export const defaultContent: SiteContent = {
  hero: {
    title: 'Về Nhà Ăn Lẩu Nướng',
    description: 'Khám phá thế giới ẩm thực lẩu nướng hấp dẫn, nơi hương vị truyền thống gặp gỡ sự sáng tạo hiện đại. Thưởng thức những món ăn tươi ngon, không khí ấm cúng bên gia đình và bạn bè.',
    ctaButton: 'Đặt Bàn Ngay',
    backgroundUrl: '', // Removed external URL to comply with no external assets
  } as HeroContent,
  about: {
    paragraphs: [
      'Nhà Ăn Lẩu Nướng là nhà hàng chuyên về lẩu và nướng Việt Nam, mang đến trải nghiệm ẩm thực đích thực. Với nguyên liệu tươi ngon được chọn lọc kỹ lưỡng, chúng tôi cam kết mang đến những bữa ăn không chỉ ngon miệng mà còn tốt cho sức khỏe.',
      'Không gian ấm cúng, dịch vụ tận tâm, Nhà Ăn Lẩu Nướng là lựa chọn lý tưởng cho mọi dịp: từ bữa tối gia đình đến tiệc công ty sôi động.',
    ],
    imageUrl: '', // Removed placeholder URL
  } as AboutContent,
  menuItems: [
    // Đồ Uống
    { 
      id: 'm1', 
      name: 'Coca', 
      description: '', 
      price: 15000, 
      icon: '🥤', 
      imageUrl: '', 
      category: 'Đồ Uống' 
    },
    { 
      id: 'm2', 
      name: 'Pepsi', 
      description: '', 
      price: 15000, 
      icon: '🥤', 
      imageUrl: '', 
      category: 'Đồ Uống' 
    },
    { 
      id: 'm3', 
      name: 'Sting', 
      description: '', 
      price: 15000, 
      icon: '🥤', 
      imageUrl: '', 
      category: 'Đồ Uống' 
    },
    { 
      id: 'm4', 
      name: 'Nước suối', 
      description: '', 
      price: 10000, 
      icon: '💧', 
      imageUrl: '', 
      category: 'Đồ Uống' 
    },
    { 
      id: 'm5', 
      name: '7up', 
      description: '', 
      price: 15000, 
      icon: '🥤', 
      imageUrl: '', 
      category: 'Đồ Uống' 
    },
    { 
      id: 'm6', 
      name: 'Trà tắc', 
      description: '', 
      price: 15000, 
      icon: '🍋', 
      imageUrl: '', 
      category: 'Đồ Uống' 
    },
    { 
      id: 'm7', 
      name: 'Trà thái xả nồi lá dứa', 
      description: '', 
      price: 20000, 
      icon: '🌿', 
      imageUrl: '', 
      category: 'Đồ Uống' 
    },
    { 
      id: 'm8', 
      name: 'Trà đào', 
      description: '', 
      price: 20000, 
      icon: '🍑', 
      imageUrl: '', 
      category: 'Đồ Uống' 
    },

    // Hải Sản (thêm các món hải sản mới)
    { 
      id: 'm9', 
      name: 'Bạch tuộc nướng muối ớt', 
      description: 'Bạch tuộc tươi nướng với muối ớt cay nồng', 
      price: 69000, 
      icon: '🦑', 
      imageUrl: '', 
      category: 'Hải Sản' 
    },
    { 
      id: 'm10', 
      name: 'Bạch tuộc nướng Singapore', 
      description: 'Bạch tuộc nướng kiểu Singapore đậm đà', 
      price: 69000, 
      icon: '🦑', 
      imageUrl: '', 
      category: 'Hải Sản' 
    },
    { 
      id: 'm11', 
      name: 'Râu bạch tuộc nướng muối ớt', 
      description: 'Râu bạch tuộc giòn tan nướng muối ớt', 
      price: 69000, 
      icon: '🦑', 
      imageUrl: '', 
      category: 'Hải Sản' 
    },
    { 
      id: 'm12', 
      name: 'Râu mực nướng muối ớt', 
      description: 'Râu mực tươi ngon nướng muối ớt', 
      price: 69000, 
      icon: '🦐', 
      imageUrl: '', 
      category: 'Hải Sản' 
    },
    { 
      id: 'm13', 
      name: 'Tôm nướng Singapore', 
      description: 'Tôm to nướng kiểu Singapore', 
      price: 69000, 
      icon: '🦐', 
      imageUrl: '', 
      category: 'Hải Sản' 
    },
    { 
      id: 'm14', 
      name: 'Tôm nướng muối ớt', 
      description: 'Tôm tươi nướng muối ớt cay', 
      price: 69000, 
      icon: '🦐', 
      imageUrl: '', 
      category: 'Hải Sản' 
    },
    { 
      id: 'm15', 
      name: 'Mực nướng muối ớt', 
      description: 'Mực ống nướng muối ớt chuẩn vị', 
      price: 79000, 
      icon: '🦑', 
      imageUrl: '', 
      category: 'Hải Sản' 
    },
    // Thêm món hải sản mới
    { 
      id: 'm36', 
      name: 'Cua biển nướng bơ tỏi', 
      description: 'Cua biển tươi nướng với bơ tỏi thơm ngon', 
      price: 120000, 
      icon: '🦀', 
      imageUrl: '', 
      category: 'Hải Sản' 
    },
    { 
      id: 'm37', 
      name: 'Hàu nướng phô mai', 
      description: 'Hàu tươi nướng phô mai tan chảy', 
      price: 45000, 
      icon: '🦪', 
      imageUrl: '', 
      category: 'Hải Sản' 
    },
    { 
      id: 'm38', 
      name: 'Sò điệp nướng mỡ hành', 
      description: 'Sò điệp tươi nướng mỡ hành dân dã', 
      price: 55000, 
      icon: '🐚', 
      imageUrl: '', 
      category: 'Hải Sản' 
    },

    // Lẩu
    { 
      id: 'm16', 
      name: 'Lẩu Thái nhỏ', 
      description: '', 
      price: 129000, 
      icon: '🍲', 
      imageUrl: '', 
      category: 'Lẩu' 
    },
    { 
      id: 'm17', 
      name: 'Lẩu Thái lớn', 
      description: '', 
      price: 189000, 
      icon: '🍲', 
      imageUrl: '', 
      category: 'Lẩu' 
    },
    { 
      id: 'm18', 
      name: 'Lẩu Tomyum nhỏ', 
      description: '', 
      price: 129000, 
      icon: '🍲', 
      imageUrl: '', 
      category: 'Lẩu' 
    },
    { 
      id: 'm19', 
      name: 'Lẩu Tomyum lớn', 
      description: '', 
      price: 189000, 
      icon: '🍲', 
      imageUrl: '', 
      category: 'Lẩu' 
    },
    { 
      id: 'm20', 
      name: 'Lẩu kim chi nhỏ', 
      description: '', 
      price: 129000, 
      icon: '🍲', 
      imageUrl: '', 
      category: 'Lẩu' 
    },
    { 
      id: 'm21', 
      name: 'Lẩu kim chi lớn', 
      description: '', 
      price: 189000, 
      icon: '🍲', 
      imageUrl: '', 
      category: 'Lẩu' 
    },

    // Thịt (chuyên về thịt bò và thêm món thịt bò mới)
    { 
      id: 'm22', 
      name: 'Thịt bò nướng', 
      description: 'Thịt bò thượng hạng nướng tươi ngon', 
      price: 89000, 
      icon: '🐄', 
      imageUrl: '', 
      category: 'Thịt' 
    },
    { 
      id: 'm23', 
      name: 'Thịt heo nướng', 
      description: 'Thịt heo nướng đậm đà vị nướng', 
      price: 79000, 
      icon: '🐖', 
      imageUrl: '', 
      category: 'Thịt' 
    },
    { 
      id: 'm24', 
      name: 'Thịt bò lá lốt', 
      description: 'Thịt bò cuốn lá lốt nướng thơm lừng', 
      price: 95000, 
      icon: '🥩', 
      imageUrl: '', 
      category: 'Thịt' 
    },
    { 
      id: 'm25', 
      name: 'Ba rọi heo', 
      description: 'Ba rọi heo nướng giòn tan', 
      price: 85000, 
      icon: '🐷', 
      imageUrl: '', 
      category: 'Thịt' 
    },
    { 
      id: 'm26', 
      name: 'Sườn non nướng', 
      description: 'Sườn non nướng mềm thơm', 
      price: 100000, 
      icon: '🦴', 
      imageUrl: '', 
      category: 'Thịt' 
    },
    // Thêm món thịt bò mới
    { 
      id: 'm39', 
      name: 'Bò nướng sốt tiêu đen', 
      description: 'Thịt bò mềm nướng với sốt tiêu đen cay nồng', 
      price: 98000, 
      icon: '🐄', 
      imageUrl: '', 
      category: 'Thịt' 
    },
    { 
      id: 'm40', 
      name: 'Bò ba chỉ nướng', 
      description: 'Bò ba chỉ nướng giòn ngoài mềm trong', 
      price: 92000, 
      icon: '🥓', 
      imageUrl: '', 
      category: 'Thịt' 
    },
    { 
      id: 'm41', 
      name: 'Thịt bò Mỹ nướng', 
      description: 'Thịt bò Mỹ cao cấp nướng chuẩn vị', 
      price: 105000, 
      icon: '🐮', 
      imageUrl: '', 
      category: 'Thịt' 
    },
    { 
      id: 'm42', 
      name: 'Bò cuốn nấm nướng', 
      description: 'Thịt bò cuốn nấm nướng thơm ngon', 
      price: 88000, 
      icon: '🍄', 
      imageUrl: '', 
      category: 'Thịt' 
    },

    // Sốt Chấm & Cốt Lẩu
    { 
      id: 'm27', 
      name: 'Sốt chấm muối ớt xanh', 
      description: '', 
      price: 15000, 
      icon: '🌶️', 
      imageUrl: '', 
      category: 'Sốt Chấm & Cốt Lẩu' 
    },
    { 
      id: 'm28', 
      name: 'Sốt chấm me', 
      description: '', 
      price: 15000, 
      icon: '🍯', 
      imageUrl: '', 
      category: 'Sốt Chấm & Cốt Lẩu' 
    },
    { 
      id: 'm29', 
      name: 'Cốt lẩu Thái', 
      description: '', 
      price: 25000, 
      icon: '🔥', 
      imageUrl: '', 
      category: 'Sốt Chấm & Cốt Lẩu' 
    },
    { 
      id: 'm30', 
      name: 'Cốt lẩu kim chi', 
      description: '', 
      price: 25000, 
      icon: '🌶️', 
      imageUrl: '', 
      category: 'Sốt Chấm & Cốt Lẩu' 
    },

    // Topping & Rau
    { 
      id: 'm31', 
      name: 'Bò viên topping', 
      description: '', 
      price: 30000, 
      icon: '🥟', 
      imageUrl: '', 
      category: 'Topping & Rau' 
    },
    { 
      id: 'm32', 
      name: 'Chả cá topping', 
      description: '', 
      price: 35000, 
      icon: '🐟', 
      imageUrl: '', 
      category: 'Topping & Rau' 
    },
    { 
      id: 'm33', 
      name: 'Rau cải thảo', 
      description: '', 
      price: 20000, 
      icon: '🥬', 
      imageUrl: '', 
      category: 'Topping & Rau' 
    },
    { 
      id: 'm34', 
      name: 'Rau muống', 
      description: '', 
      price: 20000, 
      icon: '🌿', 
      imageUrl: '', 
      category: 'Topping & Rau' 
    },
    { 
      id: 'm35', 
      name: 'Nấm kim châm', 
      description: '', 
      price: 25000, 
      icon: '🍄', 
      imageUrl: '', 
      category: 'Topping & Rau' 
    },
  ],
  combos: [
    {
      id: 'c1',
      name: 'Combo Lẩu Thái Cho 2 Người',
      description: 'Bữa ăn hoàn hảo cho cặp đôi',
      price: 299000,
      includes: ['Lẩu Thái nhỏ', 'Thịt bò 200g', 'Rau tươi', 'Mì và bún'],
      gift: '1 nước uống miễn phí',
      icon: '🍲',
      imageUrl: '',
    },
    {
      id: 'c2',
      name: 'Combo Hải Sản Nướng',
      description: 'Tươi ngon từ biển cả',
      price: 399000,
      includes: ['Bạch tuộc nướng', 'Tôm nướng', 'Mực nướng', 'Rau củ'],
      gift: '',
      icon: '🦑',
      imageUrl: '',
    },
    // Thêm combo mới liên quan đến thịt bò và hải sản
    {
      id: 'c3',
      name: 'Combo Thịt Bò Đặc Biệt',
      description: 'Combo dành riêng cho người yêu thịt bò',
      price: 350000,
      includes: ['Thịt bò nướng 300g', 'Bò nướng sốt tiêu đen', 'Rau củ nướng', 'Cơm trắng'],
      gift: '1 nước uống',
      icon: '🐄',
      imageUrl: '',
    },
    {
      id: 'c4',
      name: 'Combo Hải Sản Thịnh Soạn',
      description: 'Siêu combo hải sản tươi sống',
      price: 450000,
      includes: ['Cua biển nướng', 'Tôm hùm nướng', 'Mực tươi', 'Hàu nướng'],
      gift: 'Rau sống miễn phí',
      icon: '🦀',
      imageUrl: '',
    },
    // Add more combos as needed
  ] as ComboContent[],
  testimonials: [
    {
      quote: 'Thức ăn tuyệt vời, dịch vụ thân thiện! Chúng tôi sẽ quay lại.',
      author: 'Lan Nguyễn',
    },
    {
      quote: 'Lẩu Thái ở đây là số 1! Rất khuyến khích.',
      author: 'Minh Trần',
    },
    {
      quote: 'Không khí ấm cúng, món ăn ngon miệng.',
      author: 'Hương Phạm',
    },
  ] as Testimonial[],
  contact: {
    address: '123 Đường Lẩu Nướng, Quận 1, TP. HCM',
    phone: '0123 456 789',
    email: 'contact@launuong.com',
    hours: '10:00 - 22:00',
  } as ContactContent,
  footer: '© 2023 Nhà Ăn Lẩu Nướng. Tất cả quyền được bảo lưu.',
  gallery: [], // Empty array for gallery images; add via admin panel
  orders: [] as Order[],
  soundEnabled: true, // Default: Sound notifications enabled
} as SiteContent;
