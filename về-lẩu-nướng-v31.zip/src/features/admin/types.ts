
export interface HeroContent {
  title: string;
  description: string;
  ctaButton: string;
  backgroundUrl?: string; // URL for hero background image
}

export interface AboutContent {
  paragraphs: string[];
  imageUrl?: string; // URL or base64 for the about image
}

export interface Testimonial {
  quote: string;
  author: string;
}

export interface ContactContent {
  address: string;
  phone: string;
  email: string;
  hours: string;
}

export interface MenuItemContent {
  id: string;
  name: string;
  description: string;
  price: number;
  icon: string;
  imageUrl?: string; // Optional: URL or base64 for menu item image
  category?: string;
}

export interface ComboContent {
  id: string;
  name: string;
  description: string;
  price: number;
  includes: string[];
  gift?: string;
  icon: string;
  imageUrl?: string; // Optional: URL or base64 for combo image
}

export interface OrderItem {
  id: string;
  name: string;
  description: string;
  price: number;
  icon: string;
  imageUrl?: string;
  quantity: number;
}

export interface Order {
  id: string;
  timestamp: number;
  status: string; // 'received', 'preparing', 'ready', 'delivered', 'cancelled'
  customer: {
    name: string;
    phone: string;
    address: string;
    notes?: string;
  };
  items: OrderItem[];
  total: number;
}

export interface SiteContent {
  hero: HeroContent;
  about: AboutContent;
  menuItems: MenuItemContent[];
  combos: ComboContent[];
  testimonials: Testimonial[];
  contact: ContactContent;
  footer: string;
  gallery: string[]; // Array of image URLs or base64 strings for gallery
  orders: Order[]; // Array of orders for admin notification
  soundEnabled: boolean; // Toggle for sound notifications on new orders
}
