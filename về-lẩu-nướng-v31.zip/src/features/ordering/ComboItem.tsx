
import React from 'react';
import { ComboContent } from '../admin/types';
import './ComboItem.css';

interface ComboItemProps {
  combo: ComboContent;
  onAddToCart: (combo: ComboContent) => void;
}

const ComboItem: React.FC<ComboItemProps> = ({ combo, onAddToCart }) => {
  return (
    <div className="combo-item">
      <div className="combo-image">
        {combo.imageUrl ? (
          <img src={combo.imageUrl} alt={combo.name} className="combo-img" />
        ) : (
          <div className="combo-icon-placeholder">{combo.icon}</div>
        )}
      </div>
      <h3>{combo.name}</h3>
      {combo.description && <p className="combo-description">{combo.description}</p>}
      <div className="combo-includes">
        <h4>Bao gồm:</h4>
        <ul>
          {combo.includes.map((include, index) => (
            <li key={index}>{include}</li>
          ))}
        </ul>
      </div>
      {combo.gift && (
        <div className="combo-gift">
          <h4>Tặng kèm:</h4>
          <p>{combo.gift}</p>
        </div>
      )}
      <div className="combo-price">
        <span>Chỉ từ {combo.price.toLocaleString()} VNĐ</span>
      </div>
      <button className="add-to-cart-btn" onClick={() => onAddToCart(combo)}>
        Thêm Vào Giỏ Hàng
      </button>
    </div>
  );
};

export default ComboItem;
