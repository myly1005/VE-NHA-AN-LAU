
import React from 'react';
import { MenuItem as MenuItemType } from './types';
import './MenuItem.css';

interface MenuItemProps {
  item: MenuItemType;
  onAddToCart: (item: MenuItemType) => void;
}

const MenuItem: React.FC<MenuItemProps> = ({ item, onAddToCart }) => {
  return (
    <div className="menu-item">
      <div className="menu-image">
        {item.imageUrl ? (
          <img src={item.imageUrl} alt={item.name} className="menu-img" />
        ) : (
          <div className="menu-icon-placeholder">{item.icon}</div>
        )}
      </div>
      <h3>{item.name}</h3>
      <p>{item.description}</p>
      <span className="price">{item.price.toLocaleString()} VNĐ</span>
      <button className="add-to-cart-btn" onClick={() => onAddToCart(item)}>
        Thêm vào giỏ
      </button>
    </div>
  );
};

export default MenuItem;
