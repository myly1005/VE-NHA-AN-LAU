
import React, { useMemo, useState } from 'react';
import MenuItem from './MenuItem';
import { useContent } from '../admin/ContentProvider';
import { useCart } from './CartProvider';
import { MenuItem as MenuItemType } from '../admin/types';
import './MenuSection.css';

const MenuSection: React.FC = () => {
  const { content } = useContent();
  const { addToCart } = useCart();
  const { menuItems } = content;

  const groupedMenu = useMemo(() => {
    const groups: Record<string, MenuItemType[]> = {};
    menuItems.forEach((item) => {
      const cat = item.category || 'Khác';
      if (!groups[cat]) {
        groups[cat] = [];
      }
      groups[cat].push(item);
    });
    return groups;
  }, [menuItems]);

  const categories = Object.entries(groupedMenu).sort(([a], [b]) => a.localeCompare(b));
  const [activeCategory, setActiveCategory] = useState<string>(categories[0]?.[0] || '');

  const currentItems = groupedMenu[activeCategory] || [];

  return (
    <section className="menu">
      <div className="container">
        <h2 className="section-title">Menu</h2>
        <div className="category-tabs">
          {categories.map(([catName]) => (
            <button
              key={catName}
              className={`tab-btn ${activeCategory === catName ? 'active' : ''}`}
              onClick={() => setActiveCategory(catName)}
            >
              {catName}
            </button>
          ))}
        </div>
        {activeCategory && (
          <>
            <h3 className="category-title">{activeCategory}</h3>
            <div className="menu-grid">
              {currentItems.map((item) => (
                <MenuItem key={item.id} item={item} onAddToCart={addToCart} />
              ))}
            </div>
          </>
        )}
      </div>
    </section>
  );
};

export default MenuSection;
