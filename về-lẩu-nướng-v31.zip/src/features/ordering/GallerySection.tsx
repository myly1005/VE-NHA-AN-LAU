
import React from 'react';
import './GallerySection.css';

interface GallerySectionProps {
  images: string[];
}

const GallerySection: React.FC<GallerySectionProps> = ({ images }) => {
  return (
    <section className="gallery">
      <div className="container">
        <h2 className="section-title">Thư Viện Ảnh</h2>
        <div className="gallery-grid">
          {images.map((image, index) => (
            <div key={index} className="gallery-item">
              <img 
                src={image} 
                alt={`Gallery image ${index + 1}`} 
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default GallerySection;
