
import React from 'react';
import ComboItem from './ComboItem';
import { useContent } from '../admin/ContentProvider';
import { useCart } from './CartProvider';
import { ComboContent } from '../admin/types';
import { MenuItem as MenuItemType } from './types';
import './ComboSection.css';

const ComboSection: React.FC = () => {
  const { content } = useContent();
  const { combos } = content;
  const { addToCart } = useCart();

  const handleAddCombo = (combo: ComboContent) => {
    const cartItem: MenuItemType = {
      id: combo.id,
      name: combo.name,
      description: `Bao gồm:\n${combo.includes.map((inc) => `- ${inc}`).join('\n')}${combo.gift ? `\n\nTặng kèm: ${combo.gift}` : ''}`.trim(),
      price: combo.price,
      icon: combo.icon,
      imageUrl: combo.imageUrl,
    };
    addToCart(cartItem);
  };

  return (
    <section className="combo">
      <div className="container">
        <h2 className="section-title">Các Gói Combo Hot Nhất</h2>
        <div className="combo-grid">
          {combos.map((combo) => (
            <ComboItem key={combo.id} combo={combo} onAddToCart={handleAddCombo} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ComboSection;
