
import { MenuItemContent as MenuItemType, ComboContent, Order } from '../admin/types';

export type { MenuItemType as MenuItem };

export interface CartItem extends MenuItemType {
  quantity: number;
}

export interface OrderItem extends Omit<MenuItemType, 'category'> {
  quantity: number;
}

export type { Order };
