
import React, { useState } from 'react';
import { CartItem, OrderItem, Order } from './types';
import { persistence } from '../../utils/persistence';
import { useContent } from '../admin/ContentProvider';
import { exportSingleOrderToCSV } from '../../utils/exportUtils';
import DeliveryForm from './DeliveryForm';
import TrackOrder from './TrackOrder';
import './Cart.css';

interface CartProps {
  cart: CartItem[];
  onUpdateQuantity: (id: string, quantity: number) => void;
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
}

const Cart: React.FC<CartProps> = ({ cart, onUpdateQuantity, onRemoveItem, onClearCart }) => {
  const { addOrder } = useContent();
  const [showDeliveryForm, setShowDeliveryForm] = useState(false);
  const [showTrackOrder, setShowTrackOrder] = useState(false);
  const [orderId, setOrderId] = useState<string | null>(null);
  const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  const handleCheckout = () => {
    if (cart.length === 0) return;
    setShowDeliveryForm(true);
  };

  const handleDeliverySubmit = async (deliveryInfo: { name: string; phone: string; address: string; notes: string }) => {
    // Create order items
    const orderItems: OrderItem[] = cart.map(item => ({
      ...item,
      description: item.description ? item.description.replace(/\n/g, ' ') : '', // Flatten for display
    }));
    
    const order: Order = {
      id: Date.now().toString(),
      timestamp: Date.now(),
      status: 'received',
      customer: {
        name: deliveryInfo.name,
        phone: deliveryInfo.phone,
        address: deliveryInfo.address,
        notes: deliveryInfo.notes || undefined,
      },
      items: orderItems,
      total,
    };

    // Save order to storage
    await addOrder(order);
    setOrderId(order.id);

    // Export single order to CSV (for immediate Excel access)
    exportSingleOrderToCSV(order);

    // Simulate order processing with delivery info
    console.log('Đơn hàng:', { ...order, items: orderItems });
    alert(`Đơn hàng đã được đặt thành công!\n\nMã đơn hàng: ${order.id.slice(-6)}\nThông tin giao hàng:\n- Tên: ${deliveryInfo.name}\n- SĐT: ${deliveryInfo.phone}\n- Địa chỉ: ${deliveryInfo.address}\n- Ghi chú: ${deliveryInfo.notes || 'Không có'}\n- Tổng tiền: ${total.toLocaleString()} VNĐ\n\nCảm ơn bạn! Chúng tôi sẽ giao hàng sớm nhất. Sử dụng mã đơn để theo dõi trạng thái.\n\nFile Excel (CSV) đã được tải xuống tự động!`);
    await persistence.clear(); // Clear cart storage
    onClearCart();
    setShowDeliveryForm(false);
  };

  if (showDeliveryForm) {
    return (
      <DeliveryForm
        cart={cart}
        onSubmit={handleDeliverySubmit}
        onCancel={() => setShowDeliveryForm(false)}
      />
    );
  }

  if (showTrackOrder) {
    return (
      <TrackOrder
        onClose={() => setShowTrackOrder(false)}
        initialOrderId={orderId || undefined}
      />
    );
  }

  return (
    <div className="cart">
      <h2>Giỏ Hàng ({cart.length})</h2>
      {cart.length === 0 ? (
        <p>Giỏ hàng trống. Hãy thêm món ăn!</p>
      ) : (
        <>
          <ul className="cart-items">
            {cart.map((item) => (
              <li key={item.id} className="cart-item">
                <div className="item-info">
                  <span className="item-icon">{item.icon}</span>
                  <div>
                    <h4>{item.name}</h4>
                    <p>{item.description}</p>
                  </div>
                </div>
                <div className="item-controls">
                  <button onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}>-</button>
                  <span>{item.quantity}</span>
                  <button onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}>+</button>
                  <span className="item-price">{(item.price * item.quantity).toLocaleString()} VNĐ</span>
                  <button className="remove-btn" onClick={() => onRemoveItem(item.id)}>
                    Xóa
                  </button>
                </div>
              </li>
            ))}
          </ul>
          <div className="cart-total">
            <strong>Tổng: {total.toLocaleString()} VNĐ</strong>
          </div>
          <button className="checkout-btn" onClick={handleCheckout}>
            Đặt Hàng
          </button>
          {orderId && (
            <button className="track-btn" onClick={() => setShowTrackOrder(true)}>
              Theo Dõi Đơn Hàng #{orderId.slice(-6)}
            </button>
          )}
        </>
      )}
    </div>
  );
};

export default Cart;
