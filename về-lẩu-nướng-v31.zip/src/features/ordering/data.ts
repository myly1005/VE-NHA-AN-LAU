
// Removed hardcoded data, now managed by ContentProvider
export {};
