
import React, { useState } from 'react';
import { useCart } from './CartProvider';
import Cart from './Cart';
import './CartModal.css';

const CartModal: React.FC = () => {
  const { cart, cartCount, updateQuantity, removeItem, clearCart } = useCart();
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <button className="cart-toggle" onClick={() => setIsOpen(true)}>
        🛒 Giỏ hàng ({cartCount})
      </button>
      {isOpen && (
        <div className="modal-overlay" onClick={() => setIsOpen(false)}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <button className="close-btn" onClick={() => setIsOpen(false)}>×</button>
            <Cart
              cart={cart}
              onUpdateQuantity={updateQuantity}
              onRemoveItem={removeItem}
              onClearCart={clearCart}
            />
          </div>
        </div>
      )}
    </>
  );
};

export default CartModal;
