
import React, { useState } from 'react';
import { CartItem } from './types';
import './DeliveryForm.css';

interface DeliveryFormProps {
  cart: CartItem[];
  onSubmit: (deliveryInfo: { name: string; phone: string; address: string; notes: string }) => void;
  onCancel: () => void;
}

const DeliveryForm: React.FC<DeliveryFormProps> = ({ cart, onSubmit, onCancel }) => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    address: '',
    notes: '',
  });
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

  const validateForm = () => {
    const newErrors: { [key: string]: string } = {};
    if (!formData.name.trim()) newErrors.name = 'Tên không được để trống';
    if (!formData.phone.trim()) newErrors.phone = 'Số điện thoại không được để trống';
    else if (!/^\d{10,11}$/.test(formData.phone.replace(/\D/g, ''))) newErrors.phone = 'Số điện thoại không hợp lệ';
    if (!formData.address.trim()) newErrors.address = 'Địa chỉ không được để trống';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: '' }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      onSubmit(formData);
    }
  };

  return (
    <div className="delivery-form-container">
      <div className="delivery-header">
        <h2>Thông Tin Giao Hàng</h2>
        <p>Xác nhận đơn hàng của bạn (Tổng: {total.toLocaleString()} VNĐ)</p>
      </div>
      <form onSubmit={handleSubmit} className="delivery-form">
        <div className="form-group">
          <label htmlFor="name">Họ và Tên *</label>
          <input
            type="text"
            id="name"
            value={formData.name}
            onChange={(e) => handleChange('name', e.target.value)}
            placeholder="Nhập họ và tên"
            className={errors.name ? 'error' : ''}
          />
          {errors.name && <span className="error-message">{errors.name}</span>}
        </div>
        <div className="form-group">
          <label htmlFor="phone">Số Điện Thoại *</label>
          <input
            type="tel"
            id="phone"
            value={formData.phone}
            onChange={(e) => handleChange('phone', e.target.value)}
            placeholder="Nhập số điện thoại (10-11 số)"
            className={errors.phone ? 'error' : ''}
          />
          {errors.phone && <span className="error-message">{errors.phone}</span>}
        </div>
        <div className="form-group">
          <label htmlFor="address">Địa Chỉ Giao Hàng *</label>
          <textarea
            id="address"
            value={formData.address}
            onChange={(e) => handleChange('address', e.target.value)}
            placeholder="Nhập địa chỉ chi tiết (số nhà, đường, phường, quận, thành phố)"
            rows={3}
            className={errors.address ? 'error' : ''}
          />
          {errors.address && <span className="error-message">{errors.address}</span>}
        </div>
        <div className="form-group">
          <label htmlFor="notes">Ghi Chú (Tùy Chọn)</label>
          <textarea
            id="notes"
            value={formData.notes}
            onChange={(e) => handleChange('notes', e.target.value)}
            placeholder="Ghi chú thêm (ví dụ: gọi trước khi giao, ưu tiên giao nhanh)"
            rows={2}
          />
        </div>
        <div className="form-actions">
          <button type="button" onClick={onCancel} className="cancel-btn">
            Quay Lại
          </button>
          <button type="submit" className="submit-btn">
            Xác Nhận Đặt Hàng
          </button>
        </div>
      </form>
    </div>
  );
};

export default DeliveryForm;
