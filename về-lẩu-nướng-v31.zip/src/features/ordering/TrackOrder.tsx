
import React, { useState, useEffect } from 'react';
import { useContent } from '../admin/ContentProvider';
import { Order } from '../admin/types';
import './TrackOrder.css';

interface TrackOrderProps {
  onClose?: () => void;
  initialOrderId?: string;
}

const TrackOrder: React.FC<TrackOrderProps> = ({ onClose, initialOrderId }) => {
  const { getOrders } = useContent();
  const [orderId, setOrderId] = useState<string>(initialOrderId || '');
  const [currentOrder, setCurrentOrder] = useState<Order | null>(null);
  const [error, setError] = useState<string>('');
  const [isOpen, setIsOpen] = useState<boolean>(!!initialOrderId);

  const orders = getOrders();

  useEffect(() => {
    if (initialOrderId) {
      setOrderId(initialOrderId);
      findOrder(initialOrderId);
      setIsOpen(true);
    }
  }, [initialOrderId]);

  const findOrder = (id: string) => {
    const order = orders.find(o => o.id === id);
    if (order) {
      setCurrentOrder(order);
      setError('');
    } else {
      setCurrentOrder(null);
      setError('Không tìm thấy đơn hàng với mã này. Vui lòng kiểm tra lại.');
    }
  };

  const handleSearch = () => {
    if (orderId.trim()) {
      findOrder(orderId.trim());
    } else {
      setError('Vui lòng nhập mã đơn hàng.');
      setCurrentOrder(null);
    }
  };

  const formatDate = (timestamp: number) => {
    return new Intl.DateTimeFormat('vi-VN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    }).format(timestamp);
  };

  const getStatusLabel = (status: string) => {
    const labels: Record<string, string> = {
      received: 'Đã nhận đơn',
      preparing: 'Đang chuẩn bị',
      ready: 'Sẵn sàng giao',
      delivered: 'Đã giao',
      cancelled: 'Đã hủy',
    };
    return labels[status] || status;
  };

  const getStatusClass = (status: string) => {
    return `status-${status}`;
  };

  if (!isOpen) {
    return null;
  }

  return (
    <div className="track-overlay" onClick={onClose}>
      <div className="track-content" onClick={(e) => e.stopPropagation()}>
        <button className="close-track" onClick={onClose}>×</button>
        <h2>Theo Dõi Đơn Hàng</h2>
        <div className="search-section">
          <input
            type="text"
            value={orderId}
            onChange={(e) => setOrderId(e.target.value)}
            placeholder="Nhập mã đơn hàng (6 số cuối)"
            maxLength={6}
          />
          <button onClick={handleSearch} className="search-btn">Tìm Kiếm</button>
        </div>
        {error && <p className="error-message">{error}</p>}
        {currentOrder && (
          <div className="order-details">
            <div className="order-header">
              <h3>Đơn hàng #{currentOrder.id.slice(-6)}</h3>
              <span className="order-date">{formatDate(currentOrder.timestamp)}</span>
              <div className={`status-badge ${getStatusClass(currentOrder.status)}`}>
                {getStatusLabel(currentOrder.status)}
              </div>
            </div>
            <div className="order-customer">
              <h4>Thông tin khách hàng</h4>
              <p><strong>Tên:</strong> {currentOrder.customer.name}</p>
              <p><strong>SĐT:</strong> {currentOrder.customer.phone}</p>
              <p><strong>Địa chỉ:</strong> {currentOrder.customer.address}</p>
              {currentOrder.customer.notes && <p><strong>Ghi chú:</strong> {currentOrder.customer.notes}</p>}
            </div>
            <div className="order-items">
              <h4>Chi tiết đơn hàng</h4>
              <ul>
                {currentOrder.items.map((item, index) => (
                  <li key={index}>
                    <span className="item-icon">{item.icon}</span>
                    <div className="item-info">
                      <strong>{item.name}</strong> - {item.quantity} x {item.price.toLocaleString()} VNĐ
                      {item.description && <p>{item.description}</p>}
                    </div>
                  </li>
                ))}
              </ul>
              <div className="order-total">
                <strong>Tổng cộng: {currentOrder.total.toLocaleString()} VNĐ</strong>
              </div>
            </div>
          </div>
        )}
        {initialOrderId && !currentOrder && !error && <p>Đang tìm kiếm đơn hàng...</p>}
      </div>
    </div>
  );
};

export default TrackOrder;
